# A3 plug-in USB hub

Engineering layout for the two front-panel USB-A accessory ports. P1 mates with carrier J18 and P2 with J19. The card supplies independently switched and current-limited 5 V to the ports. The Pico owns the upstream USB connection.

KiCad reported 60 layout findings, 3 unconnected items and 0 board/schematic differences on this card. See checks/DRC.json. The schematic passed ERC. The hub card requires layout sign-off and bench verification.
