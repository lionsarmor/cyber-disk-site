# Kestrel Pocket Mars CM adapter

The top of this detachable card carries the two 100-position Hirose DF40C receptacles for the Milk-V Mars CM. Two 1×20 male through-hole strips on the underside plug into carrier sockets J1A and J1B. Both pin 1 ends point toward the Cyber Disk socket. The fine-pitch soldering belongs to the removable card.

## Assembly

| Adapter reference | Part | Quantity |
|---|---|---:|
| J1 | Hirose DF40C-100DS-0.4V(51) receptacles, installed as a pair | 2 |
| J2, J3 | Samtec TSW-120-07-G-S male strips, underside | 2 |
| R40 | Yageo RC0603JR-070RL, 0 Ω GPIO reference strap | 1 |

The adapter measures 56.2 × 52.95 mm with 2.3 mm corner radii. Its four 2.7 mm retention holes follow the CM footprint. In the Carrier A2 drawing, align adapter J2.1 to carrier J1A.1 at (17, 125) mm and adapter J3.1 to J1B.1 at (50, 125) mm. The installed 55 × 40 mm CM occupies X5.5–60.5, Y126.5–166.5 mm. Keep the header solder tails below the installed CM’s underside clearance. Choose standoff lengths after measuring the fully mated connector stack on a sample.

## Electrical interface

[Interface.csv](Interface.csv) identifies each connector position and its assigned CM pad numbers. The card carries native Lite SDIO, USB data, the Kestrel shared peripherals, supervisory UART and hybrid handshake. The six 5 V CM pads share a local top-side copper area with three plated vias to an inner 5 V pour. Ground pours provide return copper. The two USB tracks leave the Hirose pads together on the top layer and reach the male header without a via; their CAD lengths are 12.884 and 12.663 mm.

R40 feeds CM GPIO reference from the module's 3.3 V supply. The carrier supervises module power. Use the mating drawing's orientation when assembling the Hirose pair. Power down before inserting or removing either the card or the module.

The native board and single-sheet schematic open in KiCad 10. The drawings and native CAD have been checked in software. Hardware fit, 5 V operation under peak load, temperature rise and USB signal integrity still need bench measurements. The USB path includes ordinary header transitions.

The mating footprint and connector model use Raspberry Pi CM4IO mechanical data. The electrical assignments come from the Milk-V Mars CM v1.01 eMMC schematic. Source and license notices accompany the included model. [CM4IO CAD](https://datasheets.raspberrypi.com/cm4io/CM4IO-KiCAD.zip) · [Milk-V Mars CM schematic](https://github.com/milkv-mars/mars-files/blob/main/Mars-CM_Hardware_Schematices/Milk-V_Mars-CM_SCH_V1.01_2024-0425_eMMC.pdf)
