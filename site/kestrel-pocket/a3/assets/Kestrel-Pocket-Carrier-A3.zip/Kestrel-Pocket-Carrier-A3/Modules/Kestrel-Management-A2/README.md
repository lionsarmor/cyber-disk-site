# Kestrel management card A2

This removable circuit supplies the independent module power switches, bus ownership and isolation, Cyber Disk interlock, and USB voltage sensing. The two 50-way male headers on the underside mate with J15 and J16 respectively. The square pads mark pin 1. Its 68 circuit parts plus two headers are separate from the carrier BOM. The schematic preserves the A1 circuit component pin assignments for all 85 electrical nets that cross these headers.

The editable schematic passed KiCad 10 ERC. The board layout, vertical clearances, switching performance, current capacity and prototype operation require independent qualification.
