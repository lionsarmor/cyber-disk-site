from pathlib import Path
import hashlib, sys, json
import cadquery as cq

import argparse, subprocess, tempfile
parser=argparse.ArgumentParser(description="Check the removable reader against the A2 carrier and the original R12 disk")
parser.add_argument("carrier",type=Path,help="Current native A2 carrier .kicad_pcb")
parser.add_argument("cyber_disk",type=Path,help="Root of the user's original Cyber disk project")
parser.add_argument("--flatpak",action="store_true",help="Use the KiCad Flatpak instead of kicad-cli on PATH")
args=parser.parse_args()
root=Path(__file__).resolve().parent
out=root/'verification'
disk=args.cyber_disk/'mechanical/unified-r12/basic'
scratch=tempfile.TemporaryDirectory()
here=Path(scratch.name)
cli=['flatpak','run','--command=kicad-cli','org.kicad.KiCad'] if args.flatpak else ['kicad-cli']
if args.flatpak:
    # The Flatpak and host must see the exact same export path.
    scratch.cleanup()
    scratch=tempfile.TemporaryDirectory(dir=root)
    here=Path(scratch.name)
for label,pcb,model in (
    ('reader-board',root/'Kestrel-Reader-A2.kicad_pcb',None),
    ('carrier-board',args.carrier,None),('male',root/'Kestrel-Reader-A2.kicad_pcb','J1'),
    ('female',args.carrier,'J14')):
    opts=['--no-board-body','--component-filter',model] if model else ['--board-only']
    subprocess.run(cli+['pcb','export','step','--force','--user-origin','52x158.1mm','--subst-models']+opts+['-o',str(here/(label+'.step')),str(pcb.resolve())],check=True)
def solid(p):
    return cq.importers.importStep(str(p)).val()
def volume(shape):
    return sum(part.Volume() for part in shape.Solids())
carrier=solid(here/'carrier-board.step')
reader=solid(here/'reader-board.step')
male=solid(here/'male.step')
female=solid(here/'female.step')
def bounds(s):
    b=s.BoundingBox()
    return [round(getattr(b,k),4) for k in ('xmin','xmax','ymin','ymax','zmin','zmax')]
def pos(s):
    return s.rotate((0,0,0),(1,0,0),180).translate((-52,158.1,0))
def transform(s,flip,withdrawn):
    if flip:
        s=s.rotate((46,0,4.25),(46,1,4.25),180)
    s=s.translate((6,7-withdrawn,-2.23))
    return pos(s)
r={'interface':'A2 J14 and reader J1','pcb_origin_mm':[52,158.1],'reader_vs_carrier_pcb_min_clearance_mm':round(reader.distance(carrier),4),'reader_vs_carrier_pcb_intersection_mm3':round(volume(reader.intersect(carrier)),6),'metal_engagement':[],'shell_cases':[],'R12_source_sha256':{}}
for s in male.intersect(female).Solids():
    r['metal_engagement'].append({'volume_mm3':round(s.Volume(),7),'step_bounds_mm':bounds(s)})
r['note']='The generic KiCad mating model has seven intersections confined to the seven metal pin envelopes. Contact deformation, force and actual connector vendor tolerances are unmeasured.'
for name,flip in [('single',True),('ab',True),('ab',False)]:
    segs=[]
    for fn in ('body-lower-assembled.step','body-upper-assembled.step','PCB-clearance-reference-DO-NOT-PRINT.step'):
        p=disk/name/fn
        r['R12_source_sha256'][name+'/'+fn]=hashlib.sha256(p.read_bytes()).hexdigest()
        segs.append(solid(p))
    for dy in (0,12,48):
        volumes=[]
        for s in segs:
            volumes.append(round(volume(reader.intersect(transform(s,flip,dy))),6))
        print(name,flip,dy,volumes,flush=True)
        r['shell_cases'].append({'disk':name,'rolled_180':flip,'withdrawal_mm':dy,'reader_pcb_intersection_mm3':dict(zip(('lower_shell','upper_shell','media_pcb_envelope'),volumes))})
assert len(r['metal_engagement'])==7 and not r['reader_vs_carrier_pcb_intersection_mm3']
assert all(max(case['reader_pcb_intersection_mm3'].values())<1e-5 for case in r['shell_cases'])
(out/'mating-geometry.json').write_text(json.dumps(r,indent=2)+'\n')
