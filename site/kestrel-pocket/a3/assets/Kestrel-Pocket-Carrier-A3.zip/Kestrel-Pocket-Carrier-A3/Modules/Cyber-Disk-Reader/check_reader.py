"""Read placed KiCad geometry, media-library pads and 7-net connectivity from disk."""
from pathlib import Path
import hashlib, json, sys
import pcbnew as k

root=Path(__file__).resolve().parent
board=k.LoadBoard(str(root/'Kestrel-Reader-A2.kicad_pcb'))
carrier=k.LoadBoard(sys.argv[1]) if len(sys.argv)>1 else None
fps={f.GetReference():f for f in board.GetFootprints()}
gold=k.FootprintLoad(str(root/'reference'),'Contact7_F')
def mm(obj):return [round(k.ToMM(n),5) for n in (obj.x,obj.y)]
def pad(footprint,n):return footprint.FindPadByNumber(str(n))
def r4_center_to_plan(x,y):return (52-x,y-10.5)
signals=['GND','MEDIA_3V3','MEDIA_CS_N','MEDIA_SCK','MEDIA_MOSI','MEDIA_MISO','RESERVED']
j14=next(f for f in carrier.GetFootprints() if f.GetReference()=='J14') if carrier else None
checks=[]
for n,net in enumerate(signals,1):
    sc=fps['SC'+str(n)]
    land=pad(sc,1)
    assert land.GetAttribute()==k.PAD_ATTRIB_SMD and sc.GetLayer()==k.B_Cu and sc.GetOrientationDegrees()==180
    assert mm(land.GetSize())==[2.8,3.3] and mm(land.GetPosition())==[52,round(61.65+(n-1)*6,5)]
    p=pad(fps['J1'],n);g=pad(gold,n)
    assert p.GetAttribute()==k.PAD_ATTRIB_PTH and mm(p.GetPosition())==[round(59.62-2.54*(n-1),5),106.5]
    assert land.GetNetname()==p.GetNetname()=='/'+net
    crown=(52.,round(mm(land.GetPosition())[1]-.85,5))
    x,y=r4_center_to_plan(*mm(g.GetPosition()))
    assert abs(x-crown[0])+abs(y-crown[1])<1e-5
    # Inverse transform of the 0.8 mm crown's centre and both transverse extremities.
    for delta in (-.4,0,.4):
        assert g.HitTest(k.VECTOR2I(k.FromMM(52-crown[0]-delta),k.FromMM(crown[1]+10.5)))
    row={'spring':'SC'+str(n),'reader_net':net,'reader_J1_pin':n,'land_centre_mm':mm(land.GetPosition()),
         'crown_mm':crown,'media_pad_anchor_mm':[round(x,4),round(y,4)],'J1_drill_mm':mm(p.GetPosition())}
    if j14:
        h=pad(j14,n)
        assert h.GetAttribute()==k.PAD_ATTRIB_PTH
        assert mm(h.GetPosition())==[mm(p.GetPosition())[0],120.8]
        if n<7:assert h.GetNetname().split('/')[-1]==net,(n,h.GetNetname(),net)
        else:assert not h.GetNetname() or 'unconnected' in h.GetNetname().lower(),h.GetNetname()
        row['carrier_net']=h.GetNetname() or 'NC'
        row['J14_drill_mm']=mm(h.GetPosition())
    checks.append(row)
assert all(not t.Type()==k.PCB_VIA_T for t in board.GetTracks())
assert sum(p.GetAttribute()==k.PAD_ATTRIB_SMD for f in fps.values() for p in f.Pads())==7
assert sum(p.GetAttribute()==k.PAD_ATTRIB_PTH for f in fps.values() for p in f.Pads())==7
assert sum(p.GetAttribute()==k.PAD_ATTRIB_NPTH for f in fps.values() for p in f.Pads())==2
report={'pad_datum_sha256':hashlib.sha256((root/'reference/Contact7_F.kicad_mod').read_bytes()).hexdigest(),
        'carrier_checked':bool(carrier),'checks':checks,'reader_passive_nets':7,'SMT_spring_lands':7,'THT_header_pins':7,
        'M2_clearance_holes':2,'vias':0,'track_width_mm':sorted(set(round(k.ToMM(t.GetWidth()),3) for t in board.GetTracks())),
        'shoulder_extent_x_mm':[36,68],'tongue_width_mm':14,'overall_y_mm':[57.2,110],
        'disk_stop_y_mm':103,'media_contact_gap_mm':1.20,'Harwin_free_height_mm':2.0,
        'Harwin_working_range_mm':[1,1.4]}
(root/'verification/reader-registration.json').write_text(json.dumps(report,indent=2)+'\n')
print('PASS. Seven independent nets and R4 registration points; copper, header and drill audit passed.')
