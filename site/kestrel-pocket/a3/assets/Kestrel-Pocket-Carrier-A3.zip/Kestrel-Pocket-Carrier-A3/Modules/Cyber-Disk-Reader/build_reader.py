"""Regenerate the removable Cyber Disk reader PCB and linked passive schematic in KiCad 10."""
from pathlib import Path
from math import hypot, sqrt
from uuid import uuid5, NAMESPACE_URL
import json
import pcbnew as k

OUT = Path(__file__).resolve().parent
PROJECT = 'Kestrel-Reader-A2'
SIGNALS = ('GND', 'MEDIA_3V3', 'MEDIA_CS_N', 'MEDIA_SCK', 'MEDIA_MOSI', 'MEDIA_MISO', 'RESERVED')
HEADER = 'PinHeader_1x07_P2.54mm_Horizontal'
SPRING = 'Harwin_S7131-45R'
LIB = OUT / 'Reader.pretty'
PCB = k.BOARD()
PCB.GetDesignSettings().SetBoardThickness(k.FromMM(1.60))
NETS = {name: k.NETINFO_ITEM(PCB, '/'+name) for name in SIGNALS}
for net in NETS.values():
    PCB.Add(net)

def uid(key):
    return str(uuid5(NAMESPACE_URL, 'https://roddy.world/kestrel/reader-a2/'+key))

def xy(x,y):
    return k.VECTOR2I(k.FromMM(x), k.FromMM(y))

def line(start, end, layer=k.Edge_Cuts, thickness=.05):
    s=k.PCB_SHAPE(PCB)
    s.SetShape(k.SHAPE_T_SEGMENT)
    s.SetLayer(layer)
    s.SetStart(xy(*start))
    s.SetEnd(xy(*end))
    s.SetWidth(k.FromMM(thickness))
    PCB.Add(s)

def outline():
    # Tangencies and quarter-circle midpoints preserve true milled radii.
    corners=[(45,57.2,2),(59,57.2,2),(59,104,0.7),(68,104,1),(68,110,1),
             (36,110,1),(36,104,1),(45,104,0.7)]
    tangencies=[]
    for i,(x,y,r) in enumerate(corners):
        a=corners[i-1]
        c=corners[(i+1)%len(corners)]
        def unit(p):
            d=hypot(p[0]-x,p[1]-y)
            return ((p[0]-x)/d,(p[1]-y)/d)
        u,v=unit(a),unit(c)
        start=(x+r*u[0],y+r*u[1])
        end=(x+r*v[0],y+r*v[1])
        mid=(x+r*(u[0]+v[0])*(1-1/sqrt(2)),y+r*(u[1]+v[1])*(1-1/sqrt(2)))
        obj=k.PCB_SHAPE(PCB)
        obj.SetShape(k.SHAPE_T_ARC)
        obj.SetLayer(k.Edge_Cuts)
        obj.SetArcGeometry(xy(*start),xy(*mid),xy(*end))
        obj.SetWidth(k.FromMM(.05))
        PCB.Add(obj)
        tangencies.append((start,end))
    for i,(_,end) in enumerate(tangencies):
        line(end,tangencies[(i+1)%len(corners)][0])

def footprint(ref,library_name,value,x,y,angle=0,rear=False,mechanical=False):
    f=k.FootprintLoad(str(LIB),library_name)
    PCB.Add(f)
    f.SetFPID(k.LIB_ID('Reader',library_name))
    if rear:
        f.Flip(xy(0,0),False)
    f.SetOrientationDegrees(angle)
    f.SetPosition(xy(x,y))
    f.SetReference(ref)
    f.SetValue(value)
    f.Reference().SetVisible(False)
    f.Value().SetVisible(False)
    if mechanical:
        f.SetAttributes(f.GetAttributes() | k.FP_BOARD_ONLY | k.FP_EXCLUDE_FROM_POS_FILES | k.FP_EXCLUDE_FROM_BOM)
    else:
        f.SetPath(k.KIID_PATH('/'+uid('part-'+ref)))
    return f

def silk(text,x,y,size,angle=0,rear=False):
    t=k.PCB_TEXT(PCB)
    t.SetText(text)
    t.SetLayer(k.B_SilkS if rear else k.F_SilkS)
    t.SetTextSize(xy(size,size))
    t.SetTextThickness(k.FromMM(.15))
    t.SetTextAngle(k.EDA_ANGLE(angle,k.DEGREES_T))
    t.SetPosition(xy(x,y))
    t.SetMirrored(rear)
    PCB.Add(t)

def trace(path,net):
    for a,b in zip(path,path[1:]):
        t=k.PCB_TRACK(PCB)
        t.SetLayer(k.B_Cu)
        t.SetStart(xy(*a))
        t.SetEnd(xy(*b))
        t.SetWidth(k.FromMM(.32))
        t.SetNet(NETS[net])
        PCB.Add(t)

outline()
header=footprint('J1',HEADER,'1x07 right-angle plug',59.62,106.50,-90)
for pad in header.Pads():
    pad.SetNet(NETS[SIGNALS[int(pad.GetNumber())-1]])
for i,name in enumerate(SIGNALS):
    y=61.65+6*i
    sc=footprint(f'SC{i+1}',SPRING,'S7131-45R',52,y,180,rear=True)
    next(iter(sc.Pads())).SetNet(NETS[name])
    lane=58.10-.68*i
    xpin=59.62-2.54*i
    trace([(52,y),(53.6,y),(lane,y+(lane-53.6)),(lane,104.6-.92*i),(xpin,106.50)],name)
    silk(f'SC{i+1}',48.3,y,.88,rear=True)
for n,x in enumerate((39.0,65.0),1):
    footprint(f'H{n}','MountingHole_2.2mm_M2','M2 cradle',x,106.50,mechanical=True)
silk('RODDY.WORLD',50.0,76.9,1.38,90)
silk('CYBER DISK   /   READER A2',54.0,83.7,.93,90)
silk('J1',42.0,107.1,.85)
silk('1',61.6,105.2,.80,rear=True)
silk('7',42.35,105.2,.80,rear=True)
silk('A2',52,108.75,.85,rear=True)
k.SaveBoard(str(OUT/(PROJECT+'.kicad_pcb')),PCB)
(OUT/(PROJECT+'.kicad_pro')).write_text(json.dumps({'meta':{'filename':PROJECT+'.kicad_pro','version':1},'board':{'design_settings':{'rules':{'min_clearance':.2,'min_track_width':.25,'min_copper_edge_clearance':.25}}}},indent=2))
(OUT/'fp-lib-table').write_text('(fp_lib_table (version 7) (lib (name "Reader")(type "KiCad")(uri "${KIPRJMOD}/Reader.pretty")(options "")(descr "Reader A2 footprints")))\n')

# Passive symbols and pins use pin numbers matching the PCB pads.
def symbol(name,count,prefix):
    pincfg=''.join(f'(pin passive line (at -7.62 {-i*2.54:.2f} 0) (length 2.54) (name "{i+1}" (effects (font (size 1 1)))) (number "{i+1}" (effects (font (size 1 1)))))' for i in range(count))
    return f'(symbol "Reader:{name}" (pin_names (offset .5)) (in_bom yes) (on_board yes) (property "Reference" "{prefix}" (at 0 2.54 0) (effects (font (size 1 1)))) (property "Value" "{name}" (at 0 {-count*2.54:.2f} 0) (effects (font (size 1 1)))) (symbol "{name}_1_1" (rectangle (start -5.08 1.27) (end 5.08 {-((count-1)*2.54+1.27):.2f}) (stroke (width .254) (type default)) (fill (type background))) {pincfg}))'
blocks=[symbol('Contact',1,'SC'),symbol('Plug',7,'J')]
docid=uid('sheet')
entries=[]
def instance(ref,symbolname,value,fp,x,y,signals):
    entries.append(f'(symbol (lib_id "Reader:{symbolname}") (at {x} {y} 0) (unit 1) (in_bom yes) (on_board yes) (dnp no) (uuid {uid("part-"+ref)}) (property "Reference" "{ref}" (at {x} {y-3.81:.2f} 0) (effects (font (size 1.27 1.27)))) (property "Value" "{value}" (at {x+8.89:.2f} {y} 0) (effects (font (size 1 1)) (justify left))) (property "Footprint" "Reader:{fp}" (at {x} {y} 0) (effects (font (size 1 1)) hide)) (instances (project "{PROJECT}" (path "/{docid}" (reference "{ref}") (unit 1)))))')
    for i,name in enumerate(signals):
        yy=y+2.54*i
        entries.append(f'(wire (pts (xy {x-7.62:.2f} {yy:.2f}) (xy {x-12.7:.2f} {yy:.2f})) (stroke (width 0) (type default)) (uuid {uid(ref+name+"-wire")})) (label "{name}" (at {x-12.7:.2f} {yy:.2f} 0) (effects (font (size 1 1)) (justify left bottom)) (uuid {uid(ref+name+"-label")}))')
for i,net in enumerate(SIGNALS):
    instance('SC'+str(i+1),'Contact','S7131-45R',SPRING,83.82,43.18+15.24*i,[net])
instance('J1','Plug','1x07 right-angle plug',HEADER,175.26,68.58,SIGNALS)
notes='Pin 1 is inner GND. Pin 7 terminates at the reader plug and is open on the carrier.\\nThe carrier interlock controls media power and isolates the bus during motion.'
sch=f'(kicad_sch (version 20230121) (generator eeschema) (uuid {docid}) (paper "A4") (title_block (title "Kestrel Pocket / removable Cyber Disk reader") (rev "A2") (company "Roddy.world")) (lib_symbols {"".join(blocks)}) {"".join(entries)} (text "{notes}" (at 133.35 121.92 0) (effects (font (size 1.27 1.27)) (justify left)) (uuid {uid("note")})) (sheet_instances (path "/" (page "1"))))'
(OUT/(PROJECT+'.kicad_sch')).write_text(sch)
(OUT/'Reader.kicad_sym').write_text('(kicad_symbol_lib (version 20231120) (generator kicad_symbol_editor) '+''.join(s.replace('"Reader:','"',1) for s in blocks)+')')
(OUT/'sym-lib-table').write_text('(sym_lib_table (version 7) (lib (name "Reader")(type "KiCad")(uri "${KIPRJMOD}/Reader.kicad_sym")(options "")(descr "Reader A2 passive symbols")))\n')
