# Kestrel Pocket A2 removable Cyber Disk reader

The carrier's through-hole J14 socket accepts this passive reader card. Its seven gold spring contacts sit on the rear of the removable card. The two boards meet edge-to-edge in one plane. The reader slides forward, away from J14, after the disk and its two retaining screws are removed.

Open **Kestrel-Reader-A2.kicad_pro** in KiCad 10. The linked schematic, routed board, footprint and symbol libraries, STEP models and registration checks travel with the project. **Kestrel-Reader-A2.step** shows the assembled card with the contacts at free height. **Mating-drawing.svg** shows the pin direction and spring stack.

## PCB and mount

| Feature | Dimension in the carrier's front-view coordinate system |
|---|---|
| Reader stock | 1.60 mm FR-4, two layers, 52.80 mm overall length |
| Contact tongue | X45.00–59.00, leading edge Y57.20, R2 nose |
| Retaining shoulder | X36.00–68.00, Y104.00–110.00, R1 outer corners |
| Cradle screw positions | Ø2.20 mm, X39.00 and X65.00 at Y106.50 |
| Carrier clearance | J14 recess X35.00–69.00, bottom Y111.00, minimum measured board-to-board clearance 1.00 mm |
| Card J1 | 7-position 2.54 mm right-angle male header on front, pin 1 at X59.62 / Y106.50, square pin |
| Carrier J14 | 7-position 2.54 mm right-angle female socket on front, pin 1 at X59.62 / Y120.80 |
| Pin rows | 14.30 mm apart. Pin number increases toward decreasing X on both boards |
| Seated media stop | Y103.00. Header drill centres are 3.50 mm beyond the stop |
| Spring row | X52.00, crown Y60.80 + 6.00 × (pin − 1), land centre 0.85 mm farther down the insertion axis |
| Spring footprint | 2.80 × 3.30 mm copper land per contact. Seven independent 0.32 mm traces on B.Cu, zero vias |
| Contact plane | Rear solder-land surface to active disk gold 1.20 mm nominal, free spring height 2.00 mm |

Install the reader against an enclosure cradle supporting the front face of its 14 mm tongue along its length. Secure the shoulder to the cradle with two M2 screws. Keep the screw heads inside the shoulder region and past the media stop. Position the cradle against the media datum to set spring working height. Its rib and the screws must take the approximately 3.43 N combined minimum contact load at the specified working condition. The connector provides electrical continuity. A fabricated cradle, final screw lengths and tolerance measurements are still required.

For the generic KiCad horizontal connector pair, the 14.30 mm row spacing allows about 5.77 mm of pin engagement and 0.23 mm between the housing faces. Inspect the selected supplier's pin length, housing length and pin centre height before ordering. The CAD contact check found exactly seven intersections, each confined to one male pin inside the corresponding socket. The STEP files depict seated geometry with rigid contacts.

## Electrical connection

| Card spring | J1 and J14 | Signal |
|---|---:|---|
| SC1, inner rounded gold segment | 1 | GND |
| SC2 | 2 | MEDIA_3V3, switched |
| SC3 | 3 | MEDIA_CS_N |
| SC4 | 4 | MEDIA_SCK |
| SC5 | 5 | MEDIA_MOSI |
| SC6 | 6 | MEDIA_MISO |
| SC7, nearest insertion edge | 7 | Reserved. Routed to card J1; open at carrier J14 |

The carrier interlock must switch off media power and isolate the signal lines during insertion and release. Fit seven Harwin S7131-45R contacts to the reader card. Their top-down compression specification covers a 1.00–1.40 mm working range. Sliding wear, snagging, friction, contact resistance and actual stack height need bench measurements. [Harwin S7131-45R](https://www.harwin.com/products/S7131-45R)

## Geometry and electrical checks

The checked-in reference footprint is the original Cyber Disk R4 `Roddy.pretty/Contact7_F.kicad_mod`. Registration uses the actual pad geometry, including the extended, rounded SC1 segment. In the handheld, the Basic R12 single disk uses its active face toward the springs. Both faces of the R12 A/B disk share this interface. `verification/reader-registration.json` records every spring, pad centre, connector drill and net. The STEP spring shape is a local model reconstructed from the Harwin drawing. Its rounded free-state crown registers within 0.01 mm of each intended crown centre in the mesh.

OpenCascade checked the bare reader PCB against the original upper/lower R12 case solids and media PCB envelope at 0, 12 and 48 mm of withdrawal for the single-sided disk and for both A/B orientations. All 27 comparisons returned zero volume of intersection. The mainboard and reader PCB also clear one another by 1.00 mm in the seated model. These discrete samples cover rigid board geometry. The tests did not exercise a built shell, deflect the spring leaves or establish sliding-contact lifetime. Results and hashes are in `verification/mating-geometry.json`.

The stored KiCad 10 reports show zero ERC messages, DRC violations, disconnected pads and schematic/PCB parity errors. Use KiCad's Python runtime to regenerate the board from `build_reader.py` or rerun `check_reader.py <path-to-carrier.kicad_pcb>`. With CadQuery installed, run `python check_mating.py <path-to-carrier.kicad_pcb> <path-to-Cyber-disk-project>` for the STEP comparisons. Add `--flatpak` if using KiCad through Flatpak. The included board is fully routed. Refresh the STEP and run the checks after editing.

```sh
kicad-cli sch erc --exit-code-violations -o verification/erc.txt Kestrel-Reader-A2.kicad_sch
kicad-cli pcb drc --schematic-parity --exit-code-violations -o verification/drc.txt Kestrel-Reader-A2.kicad_pcb
kicad-cli pcb export step --force --user-origin 52x158.1mm -o Kestrel-Reader-A2.step Kestrel-Reader-A2.kicad_pcb
```

The bundled right-angle header and mounting-hole footprints derive from the KiCad footprints library. The header silkscreen is shortened to fit the edge-mounted position. Its stock STEP is credited to KiCad StepUp and retains its license and authorship notice in the file header. The Harwin footprint derives from the Cyber Disk contact-cartridge R1. [KiCad library license](https://www.kicad.org/libraries/license/)
