# Kestrel Pocket Carrier A3

The 98.0 × 107.8 mm Kestrel Pocket through-hole motherboard carries two full-size, side-facing USB-A sockets for keyboards, mice and gamepads. Both receptacles solder directly to the motherboard. Each has four plated signal terminals and two plated shell anchoring tabs. Every soldered component on the motherboard is through-hole. The removable computer, FPGA and support cards sit in female sockets.

Open **Kestrel-Pocket-A3-USB-A.kicad_pro** in KiCad 10. Install the standard KiCad 3D packages to see connector bodies. The symbol and footprint libraries and the resettable-fuse mechanical model are local.

## Board and interfaces

| Location | Hardware |
|---|---|
| Front upper left | JA1/JB1 accept the optional Milk-V Mars CM adapter. The removable adapter carries the fine-pitch Hirose connectors. |
| Front upper right | J2 accepts the Tang Nano 20K, using two complete 20-way female sockets. |
| Front lower bay | J15/J16 accept the removable management card for power sequencing, bus selection and disk interlock. |
| Front upper center | J14 mates sideways with the removable Cyber Disk reader. Its tongue is coplanar with the motherboard. |
| Rear lower bay | A1 accepts the header-equipped Raspberry Pi Pico supervisor. |
| Left edge, facing outward from rear | J3/J4 provide full-size USB-A ports. J17 takes **regulated 5 V**, with pin 1 ground and pin 2 positive. J6 takes a separate regulated battery/converter input. J5 selects a single supply. |
| Rear upper bay | J18/J19 accept the removable two-port HID hub card. The two 8-position headers are 22.86 mm apart. J20 breaks out the Mars native USB data pair and sense input for service. |
| Perimeter | Display/SD, keyboard, Start, audio, disk interlock and 8-pin JST XH expansion harnesses. |

J3 and J4 have separate downstream data pairs and separate switched VBUS paths. A hub card supplies both ports. Each port's VBUS comes through its own current-limited switch on that card. The Pico owns the host interface in all compute configurations. GPIO21/22 provide D+/D−. The processor-to-resistor escape is 3.18 mm per signal. R60/R61 are 22 Ω source series resistors; R62/R63 are 15 kΩ host pulldowns. Configure the Pico so its internal weak pulls do not parallel the fitted external termination in steady state. The supervisor UARTs remain available to send decoded HID events to the active Mars or Tang software. Support depends on compatible Kestrel supervisor firmware, a Mars driver or client, and a Tang core that consumes its serial input. The host link targets USB full-speed and low-speed HID peripherals. A3 provides no transparent USB host passthrough for disks, video or arbitrary USB classes. [Pico-PIO-USB upstream](https://github.com/sekigon-gonnoc/Pico-PIO-USB)

J17 pin 2 feeds the resettable fuse before the J5 external-input position. Fit a panel-mounted barrel jack or another dedicated 5 V source to this two-wire input. Never feed power into a host receptacle. The J6 and J17 inputs expect already regulated 5 V. A raw lithium cell requires its own charger and converter. J20 serves the Mars native pair independently of the Pico HID hub. Its VBUS pin is a sense input.

## Mechanical notes

The full-size receptacles use Molex 67643-3910 right-angle through-hole connectors. Their bodies are on the rear face so they clear the Mars module when installed. Port centers lie at Y127.0 and Y148.0 mm along the left edge. The front flange projects approximately 3.72 mm beyond the PCB edge. Check plug overmolds against the printed shell this opens into. [Molex mechanical drawing](https://www.molex.com/content/dam/molex/molex-dot-com/products/automated/en-us/salesdrawingpdf/676/67643/676433910_sd.pdf)

The Cyber Disk reader shoulder fits the central notch, X35–69 mm. The board top edge is Y104.20 and the cutout extends to Y111.00. J14 is centered at X52.00, with its pin row at Y120.80. The leaf spring positions are carried on the removable reader tongue. The reader’s cradle transfers insertion force into the shell. JA1/JB1 start at Y125.00 on a 33.00 mm row spacing. J15/J16 start at X20.00 on a 28.00 mm row spacing. See **Carrier-module-pin-map.csv** for actual pad coordinates.

The Tang Nano 20K's built-in USB-C is its programming/debug and USB-to-UART connector. A shell aperture can expose it for service. The service aperture requires the module to be installed. Check the switched 5 V rail and allowed simultaneous bench/handheld power before attaching an external USB cable. [Sipeed Tang Nano 20K board reference](https://en.wiki.sipeed.com/hardware/en/tang/tang-nano-20k/nano-20k.html)

## Verification and manufacturing review

The `checks` directory contains KiCad DRC with schematic parity, ERC, the native plated-pad audit, netlist and drill statistics. `manufacturing-review` contains four copper layers, solder masks, silkscreen, board cut profile, separate PTH/NPTH drills and IPC-356. L2 is dedicated to the ground reference. L3 carries secondary signal routes and 3.3 V distribution. The fuse appearance model is based on the manufacturer outline. [Bourns MF-RG datasheet](https://www.bourns.com/docs/product-datasheets/mfrg.pdf)

This design has been checked in CAD. First articles still need a populated fit test, mating-contact and print-tolerance tests, load/short-circuit tests, USB hot-plug and enumeration tests, HID interoperability tests, and a system power/backfeed check with both compute modules installed. Confirm the stackup, power-current budget, and USB routing with the fabricator before release.
