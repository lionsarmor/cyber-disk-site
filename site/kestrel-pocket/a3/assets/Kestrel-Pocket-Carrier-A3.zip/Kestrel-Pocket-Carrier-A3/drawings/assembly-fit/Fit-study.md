# Kestrel Pocket A3 assembly fit study

The A3 KiCad carrier, Mars adapter, USB hub and Cyber Disk reader share the carrier datum with the A1 reference shell. The display is an Adafruit 1770, a 2.8-inch 320 × 240 landscape LCD with a 57.6 × 43.2 mm active area. The separate CardKB U035-B keyboard sits below the game-control strip.

The front D-pad and four action buttons share a proposed through-hole input PCB with Select, Start and an MCP23017 DIP expander. Keyboard and game input use J8. Start uses J9. Two switches behind the rear paddles connect to the expander. The higher side-release controls belong to the Cyber Disk mechanism. Button travel, fasteners, rear actuators and cable routing require mechanical development.

The Tang uses the Sipeed v3920 STEP export. The 55 × 40 mm Mars CM is a mounting-outline model with approximate component packages based on Milk-V product views. The adapter plugs into JA1/JB1. The Tang plugs directly into J2. The management card is represented by its footprint allowance. The Pico and keyboard use approximate component models. The hub uses its in-progress PCB layout. The exploded diagram spreads layers for inspection.

## Closed-stack check

Z is measured from the rear face of the carrier toward the keyboard. The front socket openings reach Z10.10 mm. The assumed 2.54 mm male-header spacer puts the adapter and Nano undersides at Z12.64 mm. The adapter is 1.60 mm thick. With an assumed 3.00 mm Hirose PCB-to-PCB mating height and a 1.60 mm CM PCB, the CM component-side surface is at Z18.84 mm. The keyboard’s inner face is at Z19.00 mm. Only 0.16 mm remains above bare FR4. The approximate CM packages exceed that space. The Tang HDMI enclosure reaches Z20.82 mm, overlapping the keyboard by 1.82 mm. The horizontal gap between the compute boards is approximately 4.4 mm. Recheck the measured male header, connector stack, module thickness and keyboard with a physical prototype.

The reference shell needs more room behind the keyboard and revised USB-A openings. Game-switch placement and management-card geometry are studies. These images do not qualify the assembly for manufacture.

[Live inspector](https://disk.roddy.world/kestrel-pocket/a3/#stack) · [Sipeed dimensional model](https://dl.sipeed.com/shareURL/TANG/Nano_20K/4_Dimensional_drawing/v3920/3D) · [Milk-V Mars CM](https://milkv.io/mars-cm) · [Adafruit 1770](https://www.adafruit.com/product/1770)
