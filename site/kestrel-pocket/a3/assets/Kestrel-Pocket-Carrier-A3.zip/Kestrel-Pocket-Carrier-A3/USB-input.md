# USB input on Carrier A3

J3 and J4 are full-size USB-A sockets for keyboards, mice and gamepads. Four signal pins and two metal shell tabs on each receptacle solder through the carrier. J17 takes a separate regulated 5 V supply through F1 and the source selector. Both USB-A VBUS pins are switched outputs on the removable hub card. [Molex 67643-3910](https://www.molex.com/en-us/products/part-detail/676433910)

| Installed compute boards | Intended destination for events from either socket |
| --- | --- |
| Tang Nano 20K only | The active FPGA core, through the Pico’s Tang serial link |
| Milk-V Mars CM only | The desktop input service or bare-metal Kestrel runtime, through the Pico’s Mars serial link |
| Both boards | The active input owner chosen at the Kestrel menu |

The socketed Pico H, hub and management card are base assemblies in all three configurations. The Tang and Mars are the optional compute boards. A device’s USB connection terminates at the Pico. The selected machine receives its input events. This arrangement supports switching machines without asking the player to move a cable. The target driver should release any held buttons, keys and mouse buttons on the old machine before directing reports to the new one. Inserting two gamepads should preserve their separate identities.

## Electrical path

The two USB-A data pairs go to separate downstream ports on the hub card through J18. That card also controls each port’s 5 V supply. The upstream pair returns on J19 to the Pico’s GP21 and GP22 through R60 and R61. The Pico has a complete UART to each target. Pins GP0 and GP1 go to the Mars path and GP4 and GP5 to the Tang path. The Pico-PIO-USB host supports low- and full-speed devices and hubs. The host firmware must account for the external 15 kΩ termination resistors on this board. [Pico-PIO-USB](https://github.com/sekigon-gonnoc/Pico-PIO-USB) · [USB2512B hub](https://www.microchip.com/en-us/product/USB2512B)

## Prototype status

The board audit checks the USB-A data and power nets, Pico pins, and both serial paths. Running USB HID input still requires the A3 Pico host firmware and matching target-side handlers. The earlier A1 supervisor handles the built-in controls. External mouse reports, simultaneous gamepads, device reconnect, and handoff between physical boards still need implementation and bench testing. FPGA cores need an input adapter for the device types each core uses.

## Module service connectors

The Tang Nano 20K has one USB-C connected to its onboard programming and serial debugger and an HDMI output at the opposite end. Its USB-C faces the reserved battery volume in the current placement. The Tang can be removed from its sockets for programming. The Pico H has a Micro-USB service connector. Sipeed’s schematic ties USB-C VBUS through a fuse to the Tang 5 V rail. Using the Tang out of its socket separates the PC programming supply from the carrier. [Sipeed connector drawing](https://dl.sipeed.com/fileList/TANG/Nano_20K/1_Datasheet/Sipeed%20Tang%20nano%2020K%20Datasheet%20V1.3-en_US.pdf) · [Tang Nano 20K schematic](https://dl.sipeed.com/fileList/TANG/Nano_20K/2_Schematic/Tang_Nano_20K_3921_Schematics.pdf) · [Pico board layout](https://www.raspberrypi.com/documentation/microcontrollers/pico-series.html)
