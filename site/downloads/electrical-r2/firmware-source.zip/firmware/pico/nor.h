#ifndef CYBER_NOR_H
#define CYBER_NOR_H
#include "journal.h"
void media_init(void);
bool media_start(void);
void media_stop(void);
bool media_ok(void);
cj_flash media_flash(void);
#endif
