#include "nor.h"
#include "pico/stdlib.h"
#include "hardware/spi.h"
#include "hardware/watchdog.h"
#define CS 17
#define ARM 21
#define INTERLOCK 22
#define ERROR_N 26
static volatile bool enabled;
void media_stop(void){gpio_set_irq_enabled(ERROR_N,GPIO_IRQ_EDGE_FALL,false);enabled=false;gpio_put(ARM,0);gpio_put(CS,1);}
bool media_ok(void){return enabled&&gpio_get(INTERLOCK)&&gpio_get(ERROR_N);}
static void select(bool on){gpio_put(CS,!on);}
static uint8_t status(void){uint8_t cmd=5,r=255;select(true);spi_write_blocking(spi0,&cmd,1);spi_read_blocking(spi0,0,&r,1);select(false);return r;}
static bool wait_ready(uint32_t ms){uint64_t deadline=time_us_64()+(uint64_t)ms*1000;do{if(!media_ok())return false;if(!(status()&1))return true;watchdog_update();sleep_us(50);}while(time_us_64()<deadline);return false;}
static bool read_nor(void *ctx,uint32_t a,void *p,size_t n){(void)ctx;watchdog_update();if(a+n>4*1024*1024||!media_ok()||!wait_ready(1000))return false;uint8_t cmd[4]={3,(uint8_t)(a>>16),(uint8_t)(a>>8),(uint8_t)a};select(true);spi_write_blocking(spi0,cmd,4);spi_read_blocking(spi0,0,p,n);select(false);return media_ok();}
static bool write_enable(void){if(!wait_ready(1000)||(status()&0x7c))return false;uint8_t cmd=6;select(true);spi_write_blocking(spi0,&cmd,1);select(false);return media_ok()&&(status()&2);}
static bool program_nor(void *ctx,uint32_t a,const void *p,size_t n){(void)ctx;if(!n||n>256||a+n>4*1024*1024||a/256!=(a+n-1)/256||!write_enable())return false;uint8_t cmd[4]={2,(uint8_t)(a>>16),(uint8_t)(a>>8),(uint8_t)a};select(true);spi_write_blocking(spi0,cmd,4);spi_write_blocking(spi0,p,n);select(false);return wait_ready(20);}
static bool erase_nor(void *ctx,uint32_t a){(void)ctx;if(a%4096||a>=4*1024*1024||!write_enable())return false;uint8_t cmd[4]={0x20,(uint8_t)(a>>16),(uint8_t)(a>>8),(uint8_t)a};select(true);spi_write_blocking(spi0,cmd,4);select(false);return wait_ready(1000);}
void media_init(void){gpio_init(ARM);gpio_put(ARM,0);gpio_set_dir(ARM,GPIO_OUT);gpio_init(CS);gpio_put(CS,1);gpio_set_dir(CS,GPIO_OUT);gpio_init(INTERLOCK);gpio_set_dir(INTERLOCK,GPIO_IN);gpio_init(ERROR_N);gpio_set_dir(ERROR_N,GPIO_IN);spi_init(spi0,8000000);for(unsigned pin=18;pin<=20;pin++)gpio_set_function(pin,GPIO_FUNC_SPI);}
bool media_start(void){
 media_stop();if(!gpio_get(INTERLOCK))return false;
 for(unsigned i=0;i<25;i++){sleep_ms(1);if(!gpio_get(INTERLOCK))return false;}
 gpio_put(CS,1);gpio_put(ARM,1);sleep_ms(10);enabled=true;
 if(!media_ok()||!wait_ready(1000)){media_stop();return false;}
 uint8_t cmd=0x9f,id[3];select(true);spi_write_blocking(spi0,&cmd,1);spi_read_blocking(spi0,0,id,3);select(false);
 /* Do not issue program/erase commands to an unrecognised chip or protected media. */
 if(id[0]!=0xc2||id[1]!=0x20||id[2]!=0x16||(status()&0x7c)){media_stop();return false;}
 gpio_set_irq_enabled(ERROR_N,GPIO_IRQ_EDGE_FALL,true);return true;
}
cj_flash media_flash(void){return (cj_flash){0,read_nor,program_nor,erase_nor,4*1024*1024};}
