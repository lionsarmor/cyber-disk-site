#include "tusb.h"
#include <string.h>
/* TinyUSB development VID/PID only. Allocate a production VID/PID before release. */
static tusb_desc_device_t const device={.bLength=sizeof(tusb_desc_device_t),.bDescriptorType=TUSB_DESC_DEVICE,.bcdUSB=0x0200,.bDeviceClass=TUSB_CLASS_MISC,.bDeviceSubClass=MISC_SUBCLASS_COMMON,.bDeviceProtocol=MISC_PROTOCOL_IAD,.bMaxPacketSize0=64,.idVendor=0xcafe,.idProduct=0x4011,.bcdDevice=0x0001,.iManufacturer=1,.iProduct=2,.iSerialNumber=3,.bNumConfigurations=1};
uint8_t const *tud_descriptor_device_cb(void){return (uint8_t const *)&device;}
enum {ITF_CDC=0,ITF_CDC_DATA,ITF_MSC,ITF_COUNT};
#define TOTAL (TUD_CONFIG_DESC_LEN+TUD_CDC_DESC_LEN+TUD_MSC_DESC_LEN)
static uint8_t const configuration[]={TUD_CONFIG_DESCRIPTOR(1,ITF_COUNT,0,TOTAL,TUSB_DESC_CONFIG_ATT_REMOTE_WAKEUP,100),TUD_CDC_DESCRIPTOR(ITF_CDC,4,0x81,8,0x02,0x82,64),TUD_MSC_DESCRIPTOR(ITF_MSC,5,0x03,0x83,64)};
uint8_t const *tud_descriptor_configuration_cb(uint8_t index){(void)index;return configuration;}
uint16_t const *tud_descriptor_string_cb(uint8_t index,uint16_t language){(void)language;static uint16_t s[64];const char *text[]={"","Roddy","Cyber Disk Prototype","R1-DEVELOPMENT","Maintenance","Cyber Disk media"};if(index==0){s[0]=(TUSB_DESC_STRING<<8)|4;s[1]=0x0409;return s;}if(index>=sizeof(text)/sizeof(text[0]))return 0;size_t n=strlen(text[index]);for(size_t i=0;i<n;i++)s[1+i]=(uint8_t)text[index][i];s[0]=(uint16_t)((TUSB_DESC_STRING<<8)|(2*n+2));return s;}
