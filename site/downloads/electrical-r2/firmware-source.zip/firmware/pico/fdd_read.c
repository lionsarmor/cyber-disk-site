#include "fdd_read.h"
#include "nor.h"
#include "mfm.h"
#include "pico/stdlib.h"
#include "hardware/pio.h"
#include "hardware/dma.h"
#include "hardware/clocks.h"
#include "hardware/irq.h"
#include "read_flux.pio.h"
#define SELECT 3 /* PC drive-select 1, ribbon pin12; cable twist chooses A/B */
#define MOTOR 5 /* PC motor1, ribbon pin16 */
static PIO pio=pio0;static unsigned sm,offset;static int dma_data,dma_control;
static uint32_t track[MFM_HD_WORDS],*restart_address=track;
static volatile uint64_t revolution_start;
static volatile unsigned cylinder;
static volatile bool changed=true;
static volatile uint64_t last_step;
static bool running;
static unsigned loaded_cylinder=99,loaded_head=99;
bool fdd_selected(void){return !gpio_get(SELECT);}
static void dma_irq(void){if(dma_hw->ints0&(1u<<dma_data)){dma_hw->ints0=1u<<dma_data;revolution_start=time_us_64();}}
static void gpio_irq(unsigned pin,uint32_t event){
 if((pin==22||pin==26)&&(event&GPIO_IRQ_EDGE_FALL)){media_stop();changed=true;gpio_set_function(15,GPIO_FUNC_SIO);gpio_put(15,0);gpio_put(12,0);}
 if((pin==SELECT||pin==MOTOR)&&(event&GPIO_IRQ_EDGE_RISE)){
  gpio_set_function(15,GPIO_FUNC_SIO);gpio_put(15,0);gpio_put(12,0);
  if(pin==SELECT){gpio_put(13,0);gpio_put(14,0);gpio_put(16,0);}
 }
 if(pin==7&&(event&GPIO_IRQ_EDGE_FALL)&&fdd_selected()){
  if(gpio_get(6)){if(cylinder)cylinder--;}else if(cylinder<79)cylinder++;
  last_step=time_us_64();if(media_ok())changed=false;
 }
}
void fdd_stop(void){
 pio_sm_set_enabled(pio,sm,false);
 if(running){/* Stop chaining before aborting either channel. */
  hw_clear_bits(&dma_hw->ch[dma_data].ctrl_trig,DMA_CH0_CTRL_TRIG_EN_BITS);
  hw_clear_bits(&dma_hw->ch[dma_control].ctrl_trig,DMA_CH0_CTRL_TRIG_EN_BITS);
  dma_channel_abort(dma_data);dma_channel_abort(dma_control);
 }
 pio_sm_set_pins_with_mask(pio,sm,0,1u<<15);gpio_put(12,0);running=false;
}
void fdd_media_changed(void){changed=true;loaded_cylinder=99;fdd_stop();}
static bool sector(void *v,uint16_t lba,uint8_t *data){return cj_read(v,lba,data)==CJ_OK;}
static void start_track(unsigned sectors){
 fdd_stop();pio_gpio_init(pio,15);pio_sm_clear_fifos(pio,sm);pio_sm_restart(pio,sm);pio_sm_exec(pio,sm,pio_encode_jmp(offset));
 pio_sm_set_clkdiv(pio,sm,(float)clock_get_hz(clk_sys)/(sectors==18?25000000.0f:12500000.0f));
 dma_channel_config d=dma_channel_get_default_config(dma_data);channel_config_set_transfer_data_size(&d,DMA_SIZE_32);channel_config_set_read_increment(&d,true);channel_config_set_write_increment(&d,false);channel_config_set_dreq(&d,pio_get_dreq(pio,sm,true));channel_config_set_chain_to(&d,dma_control);
 dma_channel_configure(dma_data,&d,&pio->txf[sm],track,sectors==18?MFM_HD_WORDS:MFM_DD_WORDS,false);
 dma_channel_config c=dma_channel_get_default_config(dma_control);channel_config_set_transfer_data_size(&c,DMA_SIZE_32);channel_config_set_read_increment(&c,false);channel_config_set_write_increment(&c,false);
 dma_channel_configure(dma_control,&c,&dma_hw->ch[dma_data].al3_read_addr_trig,&restart_address,1,false);
 dma_hw->ints0=1u<<dma_data;dma_channel_set_irq0_enabled(dma_data,true);running=true;revolution_start=time_us_64();dma_start_channel_mask(1u<<dma_data);pio_sm_set_enabled(pio,sm,true);
}
void fdd_init(void){
 for(unsigned p=2;p<=11;p++){gpio_init(p);gpio_set_dir(p,GPIO_IN);}
 for(unsigned p=12;p<=16;p++){gpio_init(p);gpio_put(p,0);gpio_set_dir(p,GPIO_OUT);gpio_set_drive_strength(p,GPIO_DRIVE_STRENGTH_12MA);gpio_set_slew_rate(p,GPIO_SLEW_RATE_FAST);}
 sm=pio_claim_unused_sm(pio,true);offset=pio_add_program(pio,&read_flux_program);pio_gpio_init(pio,15);pio_sm_config c=read_flux_program_get_default_config(offset);sm_config_set_set_pins(&c,15,1);sm_config_set_out_shift(&c,false,true,32);sm_config_set_fifo_join(&c,PIO_FIFO_JOIN_TX);pio_sm_set_consecutive_pindirs(pio,sm,15,1,true);pio_sm_init(pio,sm,offset,&c);
 dma_data=dma_claim_unused_channel(true);dma_control=dma_claim_unused_channel(true);irq_set_exclusive_handler(DMA_IRQ_0,dma_irq);irq_set_enabled(DMA_IRQ_0,true);
 gpio_set_irq_enabled_with_callback(7,GPIO_IRQ_EDGE_FALL,true,gpio_irq);gpio_set_irq_enabled(22,GPIO_IRQ_EDGE_FALL,true);gpio_set_irq_enabled(SELECT,GPIO_IRQ_EDGE_RISE,true);gpio_set_irq_enabled(MOTOR,GPIO_IRQ_EDGE_RISE,true);
}
void fdd_poll(cj_volume *v,bool dock_owned){
 if(running&&gpio_get_function(15)!=GPIO_FUNC_PIO0)fdd_stop();
 bool selected=fdd_selected();bool ready=v->mounted&&media_ok()&&!dock_owned;
 gpio_put(13,selected&&cylinder==0);gpio_put(14,selected);/* Read-only FDD build: ALWAYS report write protected. */
 gpio_put(16,selected&&(changed||!ready));
 if(!ready||!selected||gpio_get(MOTOR)||time_us_64()-last_step<3000){if(running)fdd_stop();return;}
 unsigned head=!gpio_get(10),cyl=cylinder,spt=v->sectors==2880?18:9;
 if(v->sectors!=2880&&v->sectors!=1440){fdd_stop();return;}
 if(!running||loaded_cylinder!=cyl||loaded_head!=head){
  fdd_stop();if(!mfm_track(track,spt==18?MFM_HD_WORDS:MFM_DD_WORDS,cyl,head,spt,sector,v))return;
  /* A seek/eject arriving during flash reads invalidates the generated track. */
  if(cyl!=cylinder||head!=(unsigned)!gpio_get(10)||!media_ok()||!fdd_selected())return;
  loaded_cylinder=cyl;loaded_head=head;start_track(spt);
 }
 gpio_put(12,time_us_64()-revolution_start<2000);
}
