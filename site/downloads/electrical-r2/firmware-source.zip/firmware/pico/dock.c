#include "pico/stdlib.h"
#include "hardware/uart.h"
#include "hardware/watchdog.h"
#include "tusb.h"
#include "wire.h"
#include <string.h>
#include <stdio.h>
static uint16_t sequence,sectors;
static uint32_t generation;
static bool media_changed;
static bool ejected,inside_usb_callback,rpc_busy;
static uint64_t next_poll;
static bool rpc(cw_message *m,uint32_t timeout_ms){
 if(rpc_busy)return false;rpc_busy=true;
 static cw_parser parser;parser.used=0;while(uart_is_readable(uart0))(void)uart_getc(uart0);
 m->sequence=++sequence;m->status=0;m->generation=generation;uint8_t op=m->op,bytes[CW_MAX];uint16_t seq=m->sequence;unsigned n=cw_encode(m,bytes);uart_write_blocking(uart0,bytes,n);uint64_t deadline=time_us_64()+(uint64_t)timeout_ms*1000;
 while(time_us_64()<deadline){watchdog_update();if(op==CW_FORMAT&&!inside_usb_callback)tud_task();while(uart_is_readable(uart0)){cw_message r;if(cw_feed(&parser,(uint8_t)uart_getc(uart0),&r)&&r.sequence==seq&&r.op==(op|0x80)){*m=r;if(r.status==CW_CHANGED){sectors=0;media_changed=true;}rpc_busy=false;return r.status==CW_OK;}}tight_loop_contents();}
 rpc_busy=false;return false;
}
static bool info(void){cw_message m={.op=CW_INFO};if(!rpc(&m,1500)||m.length!=2){sectors=0;return false;}if(generation!=m.generation){generation=m.generation;media_changed=true;}sectors=(uint16_t)(m.data[0]|(unsigned)m.data[1]<<8);return sectors==1440||sectors==2880;}
void tud_mount_cb(void){ejected=false;next_poll=0;}
void tud_umount_cb(void){ejected=true;sectors=0;cw_message m={.op=CW_RELEASE};/* No blocking RPC inside USB callbacks. */uint8_t b[CW_MAX];m.sequence=++sequence;uart_write_blocking(uart0,b,cw_encode(&m,b));}
void tud_msc_inquiry_cb(uint8_t lun,uint8_t vendor[8],uint8_t product[16],uint8_t rev[4]){(void)lun;memcpy(vendor,"RODDY   ",8);memcpy(product,"CYBER DISK      ",16);memcpy(rev,"0001",4);}
static bool unit_attention(uint8_t lun){if(media_changed){media_changed=false;tud_msc_set_sense(lun,SCSI_SENSE_UNIT_ATTENTION,0x28,0);return true;}return false;}
bool tud_msc_test_unit_ready_cb(uint8_t lun){if(unit_attention(lun))return false;if(ejected||!sectors){tud_msc_set_sense(lun,SCSI_SENSE_NOT_READY,0x3a,0);return false;}return true;}
void tud_msc_capacity_cb(uint8_t lun,uint32_t *count,uint16_t *size){(void)lun;*count=sectors;*size=512;}
bool tud_msc_is_writable_cb(uint8_t lun){(void)lun;return !ejected&&sectors;}
bool tud_msc_start_stop_cb(uint8_t lun,uint8_t power,bool start,bool load_eject){(void)power;inside_usb_callback=true;bool ok=true;if(load_eject){cw_message m={.op=start?CW_INFO:CW_RELEASE};ok=rpc(&m,1500);if(ok){ejected=!start;if(start&&m.length==2){generation=m.generation;media_changed=true;sectors=(uint16_t)(m.data[0]|(unsigned)m.data[1]<<8);}}}inside_usb_callback=false;if(!ok)tud_msc_set_sense(lun,SCSI_SENSE_NOT_READY,0x04,0);return ok;}
int32_t tud_msc_read10_cb(uint8_t lun,uint32_t lba,uint32_t offset,void *buffer,uint32_t length){if(unit_attention(lun))return -1;if(ejected||lba>=sectors||offset+length>512)return -1;cw_message m={.op=CW_READ,.lba=(uint16_t)lba};inside_usb_callback=true;bool ok=rpc(&m,3000);inside_usb_callback=false;if(!ok||m.length!=512){tud_msc_set_sense(lun,SCSI_SENSE_MEDIUM_ERROR,0x11,0);return -1;}memcpy(buffer,m.data+offset,length);return (int32_t)length;}
int32_t tud_msc_write10_cb(uint8_t lun,uint32_t lba,uint32_t offset,uint8_t *buffer,uint32_t length){if(unit_attention(lun))return -1;if(ejected||lba>=sectors||offset+length>512)return -1;cw_message m={.op=CW_READ,.lba=(uint16_t)lba};inside_usb_callback=true;bool ok=true;if(offset||length!=512)ok=rpc(&m,3000)&&m.length==512;if(ok){m.op=CW_WRITE;m.length=512;memcpy(m.data+offset,buffer,length);ok=rpc(&m,3000);}inside_usb_callback=false;if(!ok){tud_msc_set_sense(lun,SCSI_SENSE_MEDIUM_ERROR,0x0c,0);return -1;}return (int32_t)length;}
int32_t tud_msc_scsi_cb(uint8_t lun,uint8_t const command[16],void *buffer,uint16_t length){(void)buffer;(void)length;if(command[0]==SCSI_CMD_PREVENT_ALLOW_MEDIUM_REMOVAL)return 0;if(command[0]==0x35){cw_message m={.op=CW_FLUSH};inside_usb_callback=true;bool ok=rpc(&m,3000);inside_usb_callback=false;return ok?0:-1;}tud_msc_set_sense(lun,SCSI_SENSE_ILLEGAL_REQUEST,0x20,0);return -1;}
int main(void){
 /* Leave IEC sinks deasserted, accessory outputs isolated and LEDs dark. */
 for(unsigned p=0;p<29;p++)gpio_init(p);
 for(unsigned p=7;p<=13;p++)if(p==7||p==12||p==13){gpio_put(p,0);gpio_set_dir(p,GPIO_OUT);}
 gpio_put(21,1);gpio_set_dir(21,GPIO_OUT);gpio_put(22,0);gpio_set_dir(22,GPIO_OUT);
 gpio_put(8,1);gpio_set_dir(8,GPIO_OUT);gpio_put(11,1);gpio_set_dir(11,GPIO_OUT);
 uart_init(uart0,1000000);gpio_set_function(0,GPIO_FUNC_UART);gpio_set_function(1,GPIO_FUNC_UART);tusb_init();watchdog_enable(5000,true);
 char line[64];unsigned used=0;
 for(;;){watchdog_update();tud_task();
  if(tud_mounted()&&!ejected&&time_us_64()>next_poll){info();next_poll=time_us_64()+250000;}
  while(tud_cdc_available()){
   char c=(char)tud_cdc_read_char();if(c=='\n'||c=='\r'){
    line[used]=0;used=0;
    if(!strcmp(line,"FORMAT 1440")||!strcmp(line,"FORMAT 720")){
     /* Explicit destructive maintenance operation, never automatic on insertion. */
     ejected=true;sectors=0;cw_message m={.op=CW_FORMAT,.lba=(uint16_t)(!strcmp(line,"FORMAT 1440")?2880:1440),.length=16};memcpy(m.data,"ERASE CYBER DISK!",16);bool ok=rpc(&m,1200000);tud_cdc_write_str(ok?"FORMAT OK; reconnect USB to mount\r\n":"FORMAT FAILED\r\n");tud_cdc_write_flush();
    }else if(!strcmp(line,"RELEASE")){cw_message m={.op=CW_RELEASE};ejected=true;sectors=0;rpc(&m,1500);tud_cdc_write_str("RELEASED\r\n");tud_cdc_write_flush();}
   }else if(used<sizeof(line)-1)line[used++]=c;else used=0;
  }
 }
}
