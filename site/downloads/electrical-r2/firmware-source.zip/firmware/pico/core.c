#include "pico/stdlib.h"
#include "pico/rand.h"
#include "hardware/uart.h"
#include "hardware/watchdog.h"
#include "journal.h"
#include "wire.h"
#include "nor.h"
#include "fdd_read.h"
#include <stdio.h>
#include <string.h>
static cj_volume volume;
static bool dock_owned,attempted;
static uint64_t lease;
static uint32_t generation;
static cw_parser parser;
static void reply(cw_message *m){uint8_t bytes[CW_MAX];m->op|=0x80;unsigned n=cw_encode(m,bytes);uart_write_blocking(uart0,bytes,n);}
static void request(cw_message *m){
 unsigned op=m->op;unsigned n=m->length;unsigned incoming_status=m->status;uint32_t requested_generation=m->generation;m->generation=generation;m->length=0;m->status=CW_OK;
 if(incoming_status||(op&0x80)){m->status=CW_BAD;reply(m);return;}
 if(op==CW_RELEASE){dock_owned=false;reply(m);return;}
 if(fdd_selected()){m->status=CW_BUSY;reply(m);return;}
 if(!media_ok()){m->status=CW_NO_MEDIA;reply(m);return;}
 if((op==CW_READ||op==CW_WRITE||op==CW_FLUSH)&&requested_generation!=generation){m->status=CW_CHANGED;reply(m);return;}
 dock_owned=true;lease=time_us_64();fdd_stop();
 cj_status e=CJ_OK;
 switch(op){
 case CW_INFO:if(!volume.mounted){m->status=CW_NO_MEDIA;break;}m->data[0]=(uint8_t)volume.sectors;m->data[1]=(uint8_t)(volume.sectors>>8);m->length=2;break;
 case CW_READ:if(n){m->status=CW_BAD;break;}e=cj_read(&volume,m->lba,m->data);if(!e)m->length=512;break;
 case CW_WRITE:if(n!=512){m->status=CW_BAD;break;}e=cj_write(&volume,m->lba,m->data);fdd_media_changed();break;
 case CW_FLUSH:if(!volume.mounted)e=CJ_IO;break; /* All writes are synchronous and read-verified. */
 case CW_FORMAT:
  if(n!=16||memcmp(m->data,"ERASE CYBER DISK!",16)||(m->lba!=1440&&m->lba!=2880)){m->status=CW_BAD;break;}
  volume.mounted=false;fdd_media_changed();e=cj_format(&volume,media_flash(),m->lba);break;
 default:m->status=CW_BAD;break;
 }
 if(e)m->status=e==CJ_RANGE?CW_BAD:CW_IO;
 if(!media_ok()){volume.mounted=false;dock_owned=false;m->status=CW_NO_MEDIA;}
 lease=time_us_64();reply(m);
}
int main(void){
 stdio_init_all();generation=get_rand_32();media_init();fdd_init();uart_init(uart0,1000000);gpio_set_function(0,GPIO_FUNC_UART);gpio_set_function(1,GPIO_FUNC_UART);gpio_init(28);gpio_put(28,0);gpio_set_dir(28,GPIO_OUT);watchdog_enable(5000,true);
 uint64_t last_byte=0;
 for(;;){
  watchdog_update();
  if(!gpio_get(22)){if(attempted)generation++;media_stop();volume.mounted=false;attempted=false;dock_owned=false;fdd_media_changed();}
  else if(!attempted){attempted=true;generation++;if(media_start()){cj_status e=cj_mount(&volume,media_flash());printf("media mount=%d sectors=%u\n",e,volume.sectors);fdd_media_changed();}}
  if(!media_ok()){volume.mounted=false;dock_owned=false;}
  if(dock_owned&&time_us_64()-lease>3000000)dock_owned=false;
  if(parser.used&&time_us_64()-last_byte>100000)parser.used=0;
  while(uart_is_readable(uart0)){cw_message m;last_byte=time_us_64();if(cw_feed(&parser,(uint8_t)uart_getc(uart0),&m))request(&m);}
  gpio_put(28,dock_owned);fdd_poll(&volume,dock_owned);tight_loop_contents();
 }
}
