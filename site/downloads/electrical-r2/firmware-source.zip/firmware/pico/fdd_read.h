#ifndef CYBER_FDD_READ_H
#define CYBER_FDD_READ_H
#include "journal.h"
void fdd_init(void);
void fdd_poll(cj_volume *,bool dock_owned);
void fdd_media_changed(void);
void fdd_stop(void);
bool fdd_selected(void);
#endif
