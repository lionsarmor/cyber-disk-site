#include "journal.h"
#include <string.h>
#define SUPER 0x31444a43u /* CJD1, little endian */
#define RECORD 0x31524a43u
#define COMMIT 0x434f4d54u
static uint32_t get32(const uint8_t *p){return (uint32_t)p[0]|(uint32_t)p[1]<<8|(uint32_t)p[2]<<16|(uint32_t)p[3]<<24;}
static void put32(uint8_t *p,uint32_t n){for(unsigned i=0;i<4;i++)p[i]=(uint8_t)(n>>(i*8));}
static uint64_t get64(const uint8_t *p){return get32(p)|((uint64_t)get32(p+4)<<32);}
static void put64(uint8_t *p,uint64_t n){put32(p,(uint32_t)n);put32(p+4,(uint32_t)(n>>32));}
uint32_t cj_crc32(const void *ptr,size_t n){const uint8_t *p=ptr;uint32_t c=~0u;while(n--){c^=*p++;for(unsigned i=0;i<8;i++)c=(c>>1)^((0u-(c&1))&0xedb88320u);}return ~c;}
static uint32_t address(unsigned slot){return (slot/CJ_SLOTS+2)*CJ_BLOCK+CJ_PAGE+(slot%CJ_SLOTS)*768u;}
static bool erased(const uint8_t *p,size_t n){while(n--)if(*p++!=255)return false;return true;}
static cj_status fail(cj_volume *v,cj_status e){v->mounted=false;return e;}
static bool super_valid(const uint8_t *p,cj_flash f){return get32(p)==SUPER&&get32(p+4)==1&&get32(p+8)==f.bytes&&get32(p+12)>0&&get32(p+12)<=CJ_MAX_SECTORS&&get32(p+16)==cj_crc32(p,16);}
static bool record_valid(const uint8_t *p,unsigned sectors){const uint8_t *m=p+512;return get32(m)==RECORD&&get32(m+252)==COMMIT&&get32(m+4)<sectors&&get64(m+8)>0&&get64(m+8)!=UINT64_MAX&&get32(m+20)==cj_crc32(m,20)&&get32(m+16)==cj_crc32(p,512);}
cj_status cj_mount(cj_volume *v,cj_flash f){
 memset(v,0,sizeof(*v));v->flash=f;
 if(!f.read||!f.program||!f.erase||f.bytes%CJ_BLOCK||f.bytes/CJ_BLOCK<6||f.bytes/CJ_BLOCK>CJ_MAX_BLOCKS)return CJ_FORMAT;
 uint8_t a[256],b[256];if(!f.read(f.ctx,0,a,256)||!f.read(f.ctx,CJ_BLOCK,b,256))return CJ_IO;
 bool av=super_valid(a,f),bv=super_valid(b,f);if(!av&&!bv)return CJ_FORMAT;
 if(av&&bv&&memcmp(a,b,20))return CJ_CORRUPT;
 v->sectors=(uint16_t)get32((av?a:b)+12);v->blocks=(uint16_t)(f.bytes/CJ_BLOCK);
 if(v->sectors>((v->blocks-4)*CJ_SLOTS))return CJ_FORMAT;
 for(unsigned i=0;i<v->sectors;i++)v->location[i]=CJ_NONE;
 v->next_sequence=1;uint8_t record[768];unsigned slots=(v->blocks-2)*CJ_SLOTS;
 for(unsigned i=0;i<slots;i++){
  if(!f.read(f.ctx,address(i),record,sizeof(record)))return CJ_IO;
  if(erased(record,sizeof(record))){v->free_slots++;continue;}
  v->state[i]=1;if(!record_valid(record,v->sectors))continue;
  unsigned lba=get32(record+516);uint64_t seq=get64(record+520);
  if(seq>=v->next_sequence)v->next_sequence=seq+1;
  if(seq==v->sequence[lba])return CJ_CORRUPT; /* impossible without cloning/corruption */
  if(seq>v->sequence[lba]){
   if(v->location[lba]!=CJ_NONE)v->state[v->location[lba]]=1;
   v->location[lba]=(uint16_t)i;v->sequence[lba]=seq;v->state[i]=2;
  }
 }
 v->mounted=true;return CJ_OK;
}
cj_status cj_format(cj_volume *v,cj_flash f,uint16_t sectors){
 v->mounted=false;
 if(!f.read||!f.program||!f.erase||f.bytes%CJ_BLOCK||f.bytes/CJ_BLOCK<6||f.bytes/CJ_BLOCK>CJ_MAX_BLOCKS||!sectors||sectors>CJ_MAX_SECTORS||sectors>(f.bytes/CJ_BLOCK-4)*CJ_SLOTS)return CJ_RANGE;
 /* Invalidate BOTH superblocks before destroying any data. Format is destructive. */
 for(uint32_t a=0;a<f.bytes;a+=CJ_BLOCK)if(!f.erase(f.ctx,a))return CJ_IO;
 uint8_t check[256];for(uint32_t a=0;a<f.bytes;a+=256)if(!f.read(f.ctx,a,check,256)||!erased(check,256))return CJ_IO;
 uint8_t super[256];memset(super,255,sizeof(super));put32(super,SUPER);put32(super+4,1);put32(super+8,f.bytes);put32(super+12,sectors);put32(super+16,cj_crc32(super,16));
 if(!f.program(f.ctx,0,super,256)||!f.program(f.ctx,CJ_BLOCK,super,256))return CJ_IO;
 return cj_mount(v,f);
}
cj_status cj_read(cj_volume *v,uint16_t lba,uint8_t data[512]){
 if(!v->mounted)return CJ_IO;if(lba>=v->sectors)return CJ_RANGE;
 if(v->location[lba]==CJ_NONE){memset(data,0,512);return CJ_OK;}
 uint8_t r[768];if(!v->flash.read(v->flash.ctx,address(v->location[lba]),r,768))return fail(v,CJ_IO);
 if(!record_valid(r,v->sectors)||get32(r+516)!=lba||get64(r+520)!=v->sequence[lba])return fail(v,CJ_CORRUPT);
 memcpy(data,r,512);return CJ_OK;
}
static cj_status append(cj_volume *v,uint16_t lba,const uint8_t data[512],int skip_block){
 if(v->next_sequence==UINT64_MAX)return fail(v,CJ_FULL);
 unsigned slot=0,count=(v->blocks-2)*CJ_SLOTS;
 while(slot<count&&(v->state[slot]||((int)(slot/CJ_SLOTS)==skip_block)))slot++;
 if(slot==count)return CJ_FULL;
 v->state[slot]=1;v->free_slots--; /* A failed operation is never reused without remount. */
 uint32_t a=address(slot);uint8_t m[256];memset(m,255,sizeof(m));
 put32(m,RECORD);put32(m+4,lba);put64(m+8,v->next_sequence);put32(m+16,cj_crc32(data,512));put32(m+20,cj_crc32(m,20));
 cj_flash *f=&v->flash;
 if(!f->program(f->ctx,a,data,256)||!f->program(f->ctx,a+256,data+256,256)||!f->program(f->ctx,a+512,m,256))return fail(v,CJ_IO);
 uint8_t commit[4];put32(commit,COMMIT);
 if(!f->program(f->ctx,a+764,commit,4))return fail(v,CJ_IO);
 uint8_t verify[768];if(!f->read(f->ctx,a,verify,sizeof(verify))||!record_valid(verify,v->sectors)||memcmp(verify,data,512)||get64(verify+520)!=v->next_sequence)return fail(v,CJ_IO);
 if(v->location[lba]!=CJ_NONE)v->state[v->location[lba]]=1;
 v->location[lba]=(uint16_t)slot;v->sequence[lba]=v->next_sequence++;v->state[slot]=2;return CJ_OK;
}
cj_status cj_collect(cj_volume *v){
 if(!v->mounted)return CJ_IO;
 int victim=-1;unsigned best_live=6;
 for(unsigned block=0;block<(unsigned)v->blocks-2;block++){
  unsigned live=0,dirty=0,free_here=0;
  for(unsigned i=0;i<CJ_SLOTS;i++){unsigned s=v->state[block*CJ_SLOTS+i];live+=s==2;dirty+=s==1;free_here+=s==0;}
  if(dirty&&live<best_live&&v->free_slots-free_here>=live){victim=(int)block;best_live=live;}
 }
 if(victim<0)return CJ_FULL;
 uint8_t data[512];
 for(unsigned lba=0;lba<v->sectors;lba++)if(v->location[lba]!=CJ_NONE&&v->location[lba]/CJ_SLOTS==(unsigned)victim){
  cj_status e=cj_read(v,(uint16_t)lba,data);if(e)return e;
  e=append(v,(uint16_t)lba,data,victim);if(e)return e;
 }
 /* Every live record now has a verified newer copy outside the victim. */
 uint32_t base=((unsigned)victim+2)*CJ_BLOCK;
 if(!v->flash.erase(v->flash.ctx,base))return fail(v,CJ_IO);
 for(unsigned offset=0;offset<CJ_BLOCK;offset+=512)if(!v->flash.read(v->flash.ctx,base+offset,data,512)||!erased(data,512))return fail(v,CJ_IO);
 for(unsigned i=0;i<CJ_SLOTS;i++){unsigned s=(unsigned)victim*CJ_SLOTS+i;if(v->state[s]!=0)v->free_slots++;v->state[s]=0;}
 return CJ_OK;
}
cj_status cj_write(cj_volume *v,uint16_t lba,const uint8_t data[512]){
 if(!v->mounted)return CJ_IO;if(lba>=v->sectors)return CJ_RANGE;
 while(v->free_slots<10){cj_status e=cj_collect(v);if(e)return e;}
 return append(v,lba,data,-1);
}
