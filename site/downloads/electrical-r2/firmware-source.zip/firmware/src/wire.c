#include "wire.h"
#include "journal.h"
#include <string.h>
static unsigned u16(const uint8_t *b){return b[0]|(unsigned)b[1]<<8;}
unsigned cw_encode(const cw_message *m,uint8_t b[CW_MAX]){if(m->length>512)return 0;b[0]=0xc7;b[1]=0xd1;b[2]=1;b[3]=m->op;b[4]=(uint8_t)m->sequence;b[5]=(uint8_t)(m->sequence>>8);b[6]=(uint8_t)m->lba;b[7]=(uint8_t)(m->lba>>8);b[8]=(uint8_t)m->length;b[9]=(uint8_t)(m->length>>8);b[10]=m->status;b[11]=0;for(unsigned i=0;i<4;i++)b[12+i]=(uint8_t)(m->generation>>(8*i));memcpy(b+16,m->data,m->length);uint32_t crc=cj_crc32(b,16+m->length);for(unsigned i=0;i<4;i++)b[16+m->length+i]=(uint8_t)(crc>>(8*i));return m->length+20;}
bool cw_feed(cw_parser *p,uint8_t byte,cw_message *m){
 if(p->used==CW_MAX){memmove(p->bytes,p->bytes+1,--p->used);}p->bytes[p->used++]=byte;
 while(p->used){uint8_t *b=p->bytes;if(b[0]!=0xc7||(p->used>1&&b[1]!=0xd1)||(p->used>2&&b[2]!=1)){memmove(b,b+1,--p->used);continue;}if(p->used<16)return false;
 unsigned n=u16(b+8);if(n>512||b[11]){memmove(b,b+1,--p->used);continue;}if(p->used<n+20)return false;
 uint32_t crc=0;for(unsigned i=0;i<4;i++)crc|=(uint32_t)b[16+n+i]<<(8*i);
 if(cj_crc32(b,n+16)!=crc){memmove(b,b+1,--p->used);continue;}
 m->op=b[3];m->sequence=(uint16_t)u16(b+4);m->lba=(uint16_t)u16(b+6);m->length=(uint16_t)n;m->status=b[10];m->generation=0;for(unsigned i=0;i<4;i++)m->generation|=(uint32_t)b[12+i]<<(8*i);memcpy(m->data,b+16,n);p->used-=n+20;memmove(b,b+n+20,p->used);return true;
 }return false;
}
