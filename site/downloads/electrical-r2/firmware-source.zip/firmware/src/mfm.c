#include "mfm.h"
#include <string.h>
uint16_t mfm_crc16(const uint8_t *p,size_t n){uint16_t c=0xffff;while(n--){c^=(uint16_t)*p++<<8;for(unsigned i=0;i<8;i++)c=(uint16_t)((c<<1)^((c&0x8000)?0x1021:0));}return c;}
typedef struct {uint32_t *out;size_t used,limit;unsigned previous;bool ok;} encoder;
static void raw(encoder *e,uint16_t n){if(e->used>=e->limit){e->ok=false;return;}if(!(e->used&1))e->out[e->used/2]=(uint32_t)n<<16;else e->out[e->used/2]|=n;e->used++;e->previous=n&1;}
static void byte(encoder *e,uint8_t n){uint16_t bits=0;for(int i=7;i>=0;i--){unsigned d=(n>>i)&1;bits=(uint16_t)((bits<<2)|((!e->previous&&!d)<<1)|d);e->previous=d;}raw(e,bits);}
static void repeat(encoder *e,uint8_t n,unsigned count){while(count--)byte(e,n);}
static void bytes(encoder *e,const uint8_t *p,size_t n){while(n--)byte(e,*p++);}
static void sync(encoder *e,uint16_t bits){raw(e,bits);raw(e,bits);raw(e,bits);}
bool mfm_track(uint32_t *out,size_t words,unsigned cylinder,unsigned head,unsigned sectors,mfm_read_sector read,void *ctx){
 if(cylinder>=80||head>1||(sectors!=9&&sectors!=18)||words!=(sectors==18?MFM_HD_WORDS:MFM_DD_WORDS))return false;
 encoder e={out,0,words*2,0,true};repeat(&e,0x4e,80);repeat(&e,0,12);sync(&e,0x5224);byte(&e,0xfc);repeat(&e,0x4e,50);
 for(unsigned sector=1;sector<=sectors;sector++){
  uint8_t id[8]={0xa1,0xa1,0xa1,0xfe,(uint8_t)cylinder,(uint8_t)head,(uint8_t)sector,2};
  repeat(&e,0,12);sync(&e,0x4489);bytes(&e,id+3,5);uint16_t crc=mfm_crc16(id,8);byte(&e,(uint8_t)(crc>>8));byte(&e,(uint8_t)crc);repeat(&e,0x4e,22);
  uint8_t data[516]={0xa1,0xa1,0xa1,0xfb};if(!read(ctx,(uint16_t)((cylinder*2+head)*sectors+sector-1),data+4))return false;
  repeat(&e,0,12);sync(&e,0x4489);bytes(&e,data+3,513);crc=mfm_crc16(data,516);byte(&e,(uint8_t)(crc>>8));byte(&e,(uint8_t)crc);repeat(&e,0x4e,sectors==18?84:80);
 }
 while(e.used<e.limit)byte(&e,0x4e);return e.ok;
}
