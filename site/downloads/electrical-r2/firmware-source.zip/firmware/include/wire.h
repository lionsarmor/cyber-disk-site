#ifndef CYBER_WIRE_H
#define CYBER_WIRE_H
#include <stdbool.h>
#include <stdint.h>
#define CW_MAX 532
#define CW_PAYLOAD 512
enum {CW_INFO=1,CW_READ,CW_WRITE,CW_FLUSH,CW_RELEASE,CW_FORMAT};
enum {CW_OK=0,CW_NO_MEDIA=1,CW_BUSY=2,CW_IO=3,CW_BAD=4,CW_CHANGED=5};
typedef struct {uint8_t op,status;uint16_t sequence,lba,length;uint32_t generation;uint8_t data[CW_PAYLOAD];} cw_message;
typedef struct {uint8_t bytes[CW_MAX];unsigned used;} cw_parser;
unsigned cw_encode(const cw_message *,uint8_t out[CW_MAX]);
bool cw_feed(cw_parser *,uint8_t byte,cw_message *out);
#endif
