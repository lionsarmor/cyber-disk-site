#ifndef CYBER_JOURNAL_H
#define CYBER_JOURNAL_H
#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>
#define CJ_BLOCK 4096u
#define CJ_PAGE 256u
#define CJ_SECTOR 512u
#define CJ_MAX_BLOCKS 1024u
#define CJ_MAX_SECTORS 2880u
#define CJ_SLOTS 5u
#define CJ_NONE UINT16_MAX
/* Backend must wait for WIP clear, check interlock, and bound every operation. */
typedef struct {
 void *ctx;
 bool (*read)(void *,uint32_t,void *,size_t);
 bool (*program)(void *,uint32_t,const void *,size_t);
 bool (*erase)(void *,uint32_t);
 uint32_t bytes;
} cj_flash;
typedef enum {CJ_OK=0,CJ_IO=-1,CJ_FORMAT=-2,CJ_RANGE=-3,CJ_FULL=-4,CJ_CORRUPT=-5} cj_status;
typedef struct {
 cj_flash flash;
 uint16_t blocks,sectors;
 uint16_t location[CJ_MAX_SECTORS];
 uint64_t sequence[CJ_MAX_SECTORS],next_sequence;
 uint8_t state[(CJ_MAX_BLOCKS-2)*CJ_SLOTS]; /* 0 erased, 1 dirty/old, 2 live */
 uint16_t free_slots;
 bool mounted;
} cj_volume;
uint32_t cj_crc32(const void *,size_t);
cj_status cj_format(cj_volume *,cj_flash,uint16_t sectors);
cj_status cj_mount(cj_volume *,cj_flash);
cj_status cj_read(cj_volume *,uint16_t lba,uint8_t data[CJ_SECTOR]);
cj_status cj_write(cj_volume *,uint16_t lba,const uint8_t data[CJ_SECTOR]);
/* Explicit maintenance; no background operation races with the caller. */
cj_status cj_collect(cj_volume *);
#endif
