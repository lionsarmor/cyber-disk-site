#ifndef CYBER_MFM_H
#define CYBER_MFM_H
#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>
#define MFM_HD_WORDS 6250u
#define MFM_DD_WORDS 3125u
typedef bool (*mfm_read_sector)(void *,uint16_t,uint8_t *);
uint16_t mfm_crc16(const uint8_t *,size_t);
/* 80 cylinders, two heads; 18-sector HD or 9-sector DD; 300 RPM. */
bool mfm_track(uint32_t *out,size_t words,unsigned cylinder,unsigned head,unsigned sectors,mfm_read_sector,void *);
#endif
