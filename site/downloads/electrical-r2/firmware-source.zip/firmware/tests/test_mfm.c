#include "mfm.h"
#include <assert.h>
#include <stdio.h>
static uint32_t track[MFM_HD_WORDS];
static bool sector(void *c,uint16_t lba,uint8_t *out){(void)c;for(unsigned i=0;i<512;i++)out[i]=(uint8_t)(lba+i);return true;}
static uint16_t raw(unsigned i){return (uint16_t)(track[i/2]>>((i&1)?0:16));}
static uint8_t data(unsigned i){uint16_t n=raw(i);uint8_t d=0;for(int b=14;b>=0;b-=2)d=(uint8_t)((d<<1)|((n>>b)&1));return d;}
int main(void){
 assert(mfm_crc16((const uint8_t *)"123456789",9)==0x29b1);
 for(unsigned spt=9;spt<=18;spt+=9)for(unsigned cylinder=0;cylinder<80;cylinder++)for(unsigned head=0;head<2;head++){
  unsigned words=spt==18?MFM_HD_WORDS:MFM_DD_WORDS;assert(mfm_track(track,words,cylinder,head,spt,sector,0));unsigned ids=0,records=0;
  for(unsigned i=0;i+520<words*2;i++)if(raw(i)==0x4489&&raw(i+1)==0x4489&&raw(i+2)==0x4489){
   unsigned n=data(i+3)==0xfe?10:data(i+3)==0xfb?518:0;if(!n)continue;uint8_t decoded[518];for(unsigned j=0;j<n;j++)decoded[j]=data(i+j);assert(mfm_crc16(decoded,n)==0);
   if(n==10){ids++;assert(decoded[4]==cylinder&&decoded[5]==head&&decoded[6]==ids&&decoded[7]==2);}else{records++;for(unsigned j=0;j<512;j++)assert(decoded[j+4]==(uint8_t)(((cylinder*2+head)*spt+records-1)+j));}i+=n-1;
  }
  assert(ids==spt&&records==spt);
 }
 puts("MFM: independent CRC/CHRN/data decode of 320 HD/DD tracks; PASS");return 0;
}
