#include "journal.h"
#include <assert.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#define BYTES (12*4096)
#define SECTORS 20
static unsigned char memory[BYTES],saved[BYTES],truth[SECTORS][512];
static long cut=-1,mutations;
static bool read_flash(void *c,uint32_t a,void *p,size_t n){(void)c;assert(a+n<=BYTES);memcpy(p,memory+a,n);return true;}
static bool mutate(void){if(cut==0)return false;if(cut>0)cut--;mutations++;return true;}
static bool program(void *c,uint32_t a,const void *p,size_t n){(void)c;assert(n&&a+n<=BYTES&&a/256==(a+n-1)/256);const uint8_t *s=p;for(size_t i=0;i<n;i++){assert((memory[a+i]&s[i])==s[i]);if(!mutate())return false;memory[a+i]&=s[i];}return true;}
static bool erase_block(void *c,uint32_t a){(void)c;assert(a%4096==0&&a+4096<=BYTES);for(unsigned i=0;i<4096;i++){if(!mutate())return false;memory[a+i]=255;}return true;}
static cj_flash flash={0,read_flash,program,erase_block,BYTES};
static cj_volume v;
static void pattern(uint8_t *p,unsigned n){for(unsigned i=0;i<512;i++)p[i]=(uint8_t)((n*23+i*11)^(n>>(i%13)));}
static void check_all(int changing,const uint8_t *next){uint8_t out[512];for(unsigned i=0;i<SECTORS;i++){assert(cj_read(&v,(uint16_t)i,out)==CJ_OK);assert(!memcmp(out,truth[i],512)||((int)i==changing&&!memcmp(out,next,512)));}}
int main(void){
 memset(memory,255,sizeof(memory));assert(cj_mount(&v,flash)==CJ_FORMAT);assert(cj_format(&v,flash,SECTORS)==CJ_OK);
 for(unsigned i=0;i<SECTORS;i++){pattern(truth[i],i+1);assert(cj_write(&v,(uint16_t)i,truth[i])==CJ_OK);}
 memcpy(saved,memory,BYTES);uint8_t next[512];pattern(next,888);unsigned cases=0;
 /* Cut at every byte of each data/metadata/commit program operation. */
 for(long n=0;n<=772;n++){memcpy(memory,saved,BYTES);cut=-1;assert(cj_mount(&v,flash)==CJ_OK);cut=n;assert(cj_write(&v,3,next)==(n<772?CJ_IO:CJ_OK));cut=-1;assert(cj_mount(&v,flash)==CJ_OK);check_all(3,next);cases++;}
 memcpy(memory,saved,BYTES);assert(cj_mount(&v,flash)==CJ_OK);
 /* Make a victim containing both stale and live sectors. */
 pattern(next,999);assert(cj_write(&v,0,next)==CJ_OK);memcpy(truth[0],next,512);memcpy(saved,memory,BYTES);
 mutations=0;assert(cj_collect(&v)==CJ_OK);long gc_bytes=mutations;assert(gc_bytes>4096);
 for(long n=0;n<=gc_bytes;n++){memcpy(memory,saved,BYTES);cut=-1;assert(cj_mount(&v,flash)==CJ_OK);cut=n;(void)cj_collect(&v);cut=-1;assert(cj_mount(&v,flash)==CJ_OK);check_all(-1,0);cases++;}
 /* Long overwrite/GC run with resets, then corruption detection. */
 for(unsigned n=0;n<5000;n++){unsigned lba=(n*17)%SECTORS;pattern(next,n+5000);assert(cj_write(&v,(uint16_t)lba,next)==CJ_OK);memcpy(truth[lba],next,512);if(n%71==0){assert(cj_mount(&v,flash)==CJ_OK);check_all(-1,0);}}
 check_all(-1,0);assert(cj_read(&v,SECTORS,next)==CJ_RANGE);
 printf("journal: %u byte-cut recovery cases; 5000 overwrite/GC writes; PASS\n",cases);
 return 0;
}
