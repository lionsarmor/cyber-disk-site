#include "wire.h"
#include <assert.h>
#include <stdio.h>
#include <string.h>
int main(void){cw_message a={.op=CW_WRITE,.sequence=0x1234,.lba=2800,.generation=0x82735149},b;uint8_t bytes[CW_MAX];cw_parser p={0};unsigned cases=0;
 for(unsigned n=0;n<=512;n++){
  a.length=(uint16_t)n;for(unsigned i=0;i<n;i++)a.data[i]=(uint8_t)(i*17+n);
  unsigned size=cw_encode(&a,bytes);assert(size==n+20);bool got=false;
  for(unsigned i=0;i<size;i++){got=cw_feed(&p,bytes[i],&b);assert(got==(i==size-1));}
  assert(b.generation==a.generation&&b.sequence==a.sequence&&b.lba==a.lba&&b.op==a.op&&b.length==a.length&&!memcmp(a.data,b.data,n));cases++;
 }
 a.length=512;unsigned size=cw_encode(&a,bytes);
 for(unsigned bit=0;bit<size*8;bit++){
  memset(&p,0,sizeof(p));bytes[bit/8]^=1u<<(bit%8);for(unsigned i=0;i<size;i++)assert(!cw_feed(&p,bytes[i],&b));bytes[bit/8]^=1u<<(bit%8);cases++;
 }
 memset(&p,0,sizeof(p));for(unsigned i=0;i<100;i++)assert(!cw_feed(&p,0x33,&b));for(unsigned i=0;i<size;i++)assert(cw_feed(&p,bytes[i],&b)==(i==size-1));
 printf("wire: %u framing/bit corruption cases and noise resynchronization; PASS\n",cases);return 0;
}
