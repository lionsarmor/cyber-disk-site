# External dock R2 — Basic case

R2 translates the approved red Basic concept into solid CAD. The R1 electrical design and the R4 internal drive mechanism remain unchanged. This revision is a mechanical appearance prototype, not a manufacturing release.

## Changes

- Same nominal 168 × 280 × 54 mm envelope including feet; 52 mm body height. Resting eject button adds 8 mm at the front.
- Red structural shell, 5 mm outer plan corner radii and a real 4 mm fillet on the roof perimeter. Lid screw centres move 0.8 mm inward to clear that fillet. The original CD-ROM-compatible core bezel and mounting holes are retained.
- A 116 × 19 mm rounded capsule recess on top, 0.7 mm deep. At least 1.8 mm roof remains below the deepest decorative recess.
- Rounded 112 × 53 mm label recess, 0.35 mm deep. A shell-matched 111.4 × 52.4 × 0.15 mm adhesive-label proxy carries the supplied RODDY vector logo and CYBER DISK lettering. Artwork is a decal reference, not an extra print piece.
- Removed both orange shoulder parts and their wall pockets. Side walls now retain their full 3.2 mm nominal section, apart from the designed light window.
- One continuous opal U-shaped lens, flush with the exterior, wraps around both front corners and 50 mm down each side. A wider lower flange locates in a stepped channel with nominal 0.2 mm clearance; the lens is installed while the core carrier is removed.
- Black/charcoal drive bezel, flap and eject-button colourway in the viewer. Geometry and button stroke are unchanged: 8 mm proud at rest and 2 mm proud when pressed.
- Nine printed case/carrier/lens parts. The roof and chassis remain split to fit a 256 mm print bed. Their seams and recessed lid screws remain visible in the CAD; the concept image was smoother than a multi-part FDM assembly.

## Assembly and service

The original rear-sliding drive carrier, removable daughterboard tray, underfloor joint bridge, side mounting screws and six M2 lid screws remain. No added front-face screws, moving mechanisms or snap tabs. Lid screws still use heat-set inserts: select a specific insert and calibrate the holes before printing a full case. The shell-colour label is applied after assembly; it does not cover service screws or span the lid joint.

The diffuser is a separate translucent print. The existing LED/lightwell allocation remains behind the front bezel; even brightness along the side returns is not proven. Print a lens/lightwell sample and test scattering, LED spacing and brightness before freezing an LED part. Do not assume the rendered glow predicts optics.

## Validation and limits

See `checks.json` for Boolean interference checks between printable parts, the drive core, roof, diffuser and carrier sweep samples. Exported solids must be valid and every printed part must be a single connected body. Samples are nominal CAD checks, not a continuous motion proof or a tolerance/strength test.

The daughterboard is still R1 and **unrouted / not ready to order**. Connector mounting envelopes, print fits, spring forces, light uniformity, thermal behaviour, screw lengths and insert pull-out strength need physical qualification. No electronics routing, supplier qualification or firmware completion is implied by this case revision. Power remains an external regulated 5 V centre-positive adapter; no mains enters the case. See the R1 electrical notes in the source project.

## Regeneration

Run `tools/build_external_dock_r2.py`, then `tools/check_external_dock_fit_r2.py` with CadQuery, fontTools and Shapely installed. `tools/logo_geometry.py` converts the actual supplied SVG curves into thin CAD artwork solids. Use `web-inspector/pack_external.py <site-directory>` to update all four external-case inspection scenes and their STEP/STL download bundle.
